<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<script>
import { websocket } from '@/app/mixins'
export default{
  name: 'App',
  mixins: [websocket]
}
</script>
